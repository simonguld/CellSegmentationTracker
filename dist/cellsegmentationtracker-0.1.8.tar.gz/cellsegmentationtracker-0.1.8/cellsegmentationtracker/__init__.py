__author__ = 'Simon Guldager Andersen'
__version__ = "0.1.8"

from . import utils
from .CellSegmentationTracker import CellSegmentationTracker
